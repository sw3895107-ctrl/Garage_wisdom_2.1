
const express = require('express');
const multer = require('multer');
const cloudinary = require('cloudinary').v2;
const Post = require('../models/Post');
const auth = require('../middleware/auth');

cloudinary.config();

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage() });

router.post('/', auth, upload.single('image'), async (req, res) => {
  let imageUrl = '';
  if (req.file) {
    const result = await cloudinary.uploader.upload_stream(
      { resource_type: 'image' },
      async (error, result) => {
        if (error) return res.status(500).json({ error });
        const post = new Post({
          title: req.body.title,
          content: req.body.content,
          image: result.secure_url
        });
        await post.save();
        res.json(post);
      }
    );
    result.end(req.file.buffer);
  } else {
    const post = new Post(req.body);
    await post.save();
    res.json(post);
  }
});

router.get('/', async (req, res) => {
  const posts = await Post.find().sort({ createdAt: -1 });
  res.json(posts);
});

module.exports = router;
